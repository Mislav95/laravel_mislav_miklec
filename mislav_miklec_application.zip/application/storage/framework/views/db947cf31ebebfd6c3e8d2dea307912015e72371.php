<?php $__env->startSection('content'); ?>

<table class="table">
<a class="btn btn-primary float-right" href="/leagues/new">New</a>
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">League name</th>
      <th scope="col">Country name</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $leagues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $league): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <tr>
      <td><?= $league->id ?></td>
      <td><?= $league->league_name ?></td>
      <td><?= $league->country->country_name ?></td>
      
    </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>