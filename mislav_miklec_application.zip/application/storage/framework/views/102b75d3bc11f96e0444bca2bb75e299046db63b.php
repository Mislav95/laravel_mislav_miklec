<?php $__env->startSection('content'); ?>

<form method="post" action="/continents">
<?php echo csrf_field(); ?>

<div class="form-group">
    <input class="form-control" name="continent_name" type="text" placeholder="Continent name">
</div>
<div class="form-group">
    <input class="form-control" name="number_of_countries" type="text" placeholder="Number of countries">
</div>
<div class="form-group">
    <input class="form-control" name="native_name" type="text" placeholder="Native name">
</div>

<button type="submit" class="btn btn-success">Submit</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>